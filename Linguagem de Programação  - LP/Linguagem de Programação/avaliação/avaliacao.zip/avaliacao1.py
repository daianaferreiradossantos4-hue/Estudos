a = int(input("digite um numero inteiro: "))
b = int(input("digite o segundo numero inteiro: "))

if a > b:
    print("o maior numero é: " , a)

elif b > a:
    print("o menor  numero é: " , b)

else:
    print("os numeros sao iguais")
    
    
