def saudacao(nome="visitante "):
    print(f"Bem-vindo(a),{nome}")

saudacao()
saudacao("Daiana")

