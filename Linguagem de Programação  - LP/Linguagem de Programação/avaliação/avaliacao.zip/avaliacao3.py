def soma(a, b):
    return a + b


resultado1 = soma(3, 5)
print(f"a soma de 3 e 5 é {resultado1}")


resultado2 = soma(10, 7)
print(f"a soma de 10 e 7 é {resultado2}")