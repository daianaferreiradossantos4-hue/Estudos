nome = "Daiana"
nota1 = 8.5
nota2 = 7.0

media = (nota1 + nota2) / 2
print(media)