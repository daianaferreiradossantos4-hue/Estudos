nota = 7

if nota >= 7:
    print("Aprovado")
elif nota>= 5:
    print("Recuperação")
else:
    print("Reprovado")


idade = 18
tem_carteira = True
 
if idade >= 18 and tem_carteira:
    print("Pode dirigir.")



# == igual
# ! = diferente
# > maior
# < menor
# >= maior ou igual
# <= menor ou igual
# and (e)
# or (ou)