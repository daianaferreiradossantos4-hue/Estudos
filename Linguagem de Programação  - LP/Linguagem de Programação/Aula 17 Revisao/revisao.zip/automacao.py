import pyautogui
pyautogui.moveTo(600, 500, duration=2)

#Clicar:

pyautogui.click()



#Digitar:

pyautogui.write("Olá mundo!" , interval=0.1)


#Pressionar tela:

pyautogui.press("enter")







