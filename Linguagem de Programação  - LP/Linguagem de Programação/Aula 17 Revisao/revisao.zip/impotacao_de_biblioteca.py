import math
import pandas as pd
import pyautogui
from datetime import datetime


#importando com apelido(muito comum)

import pandas as pd


#por que importar biblioteca?
#evite reinventar a roda
#acelera o desenvolvimento
#facilita tarefas complexas
#permite usar ferramentas criadas por especialistas