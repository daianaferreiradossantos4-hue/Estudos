#FOR

for i in range(5):
    print("Olá", i)




frutas = ["maçã" , "banana", "uva"]

for fruta in frutas:
    print(fruta)



#while


contador = 1
 

while contador <= 5:
    print(contador)
    contador += 1