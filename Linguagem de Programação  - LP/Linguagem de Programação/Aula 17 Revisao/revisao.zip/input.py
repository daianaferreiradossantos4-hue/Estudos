nome = input("Digite seu nome: ")
idade = int(input("Digite sua idade: "))

print(f"Olá,{nome}. Você tem {idade}  anos.")



#tudo que vem do input é str.Para numeros, converta: int(), float().