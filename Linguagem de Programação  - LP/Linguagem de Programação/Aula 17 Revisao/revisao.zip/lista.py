#criando lista:

frutas = ["maçã", "banana", "mamão"]


#Acessando:

print(frutas[0])  #maçã



#Adicionando:

frutas.append("uva")


#Removendo:

frutas.remove("banana")


#Alterando:

frutas[1] = "abacaxi"

