import pyautogui
import time


time.sleep(1)
pyautogui.press("win")
pyautogui.write("chrome")
pyautogui.press("enter")
time.sleep(1)
pyautogui.write("wikipedia.org")
pyautogui.press("enter")