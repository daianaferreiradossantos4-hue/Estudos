import pyautogui
import time

time.sleep(3)
pyautogui.click(100,500)